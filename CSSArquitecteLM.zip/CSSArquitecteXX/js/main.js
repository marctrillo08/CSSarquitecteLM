function mou(queimagen){

    if (queimagen == -1){

        document.getElementById("imatge").src = "img/pages10.jpg";


    } else
    {
        document.getElementById("imatge").src = "img/pages2.jpg";
    }
}